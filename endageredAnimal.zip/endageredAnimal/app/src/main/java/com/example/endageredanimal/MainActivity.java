package com.example.endageredanimal;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("우리나라의 멸종 위기 동물");

        GridView gv = (GridView) findViewById(R.id.animals);
        MyGridAdapter gridAdapter = new MyGridAdapter(this);
        gv.setAdapter(gridAdapter);
    }

    public class MyGridAdapter extends BaseAdapter {

        Context context;
        public MyGridAdapter(Context c){
            context = c;
        }

        @Override
        public int getCount() {
            return animalID.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {

            return 0;
        }
        String[] animalName = {
                "반달가슴곰", "붉은여우", "한국표범",
                "스라소니", "사향노루", "수달",
                "꽃사슴", "백두산호랑이", "늑대"
        };

        Integer[] animalID = {
                R.drawable.bear, R.drawable.fox, R.drawable.leopard,
                R.drawable.lynx, R.drawable.muskdeer, R.drawable.otter,
                R.drawable.sikadeer, R.drawable.tiger, R.drawable.wolf
        };

        String[] animalSpecies = {
                "아시아흑곰(U. thibetanus)","붉은여우(V. vulpes)", "표범(P. pardus)",
                "스라소니(L. lynx)", "사향노루(M. moschiferus)", "수달(Lutra lutra)",
                "꽃사슴(Cervus nippon)", "호랑이(P. tigris)", "늑대(C. lupus)"
        };
        String[] habitatPlace = {
                "태국, 미얀마, 러시아, 일본, 인도, 부탄, 네팔, 이란, 파키스탄, 아프가니스탄, 대만",
                "유라시아 북부(히말라야 산맥 포함), 북아메리카 남부, 아이슬란드, 북아프리카, 오스트레일리아",
                "아시아, 아프리카 등지",
                "유라시아",
                "한국, 중국, 러시아, 우즈베키스탄, 투르크메니스탄, 사할린, 몽골",
                "유라시아(중,소형), 남아메리카(대형)",
                "남한(멸종), 북한, 중국",
                "남한(멸종), 만주 및 러시아 연해주 시호테알린 산맥",
                "북아메리카, 유라시아, 북아프리카"
        };
        String[] differenceName = {
                "아시아흑곰","불여우", "만주표범",
                "시라소니", "궁노루", "물족제비",
                "대륙사슴", "시베리아호랑이", "말승냥이"
        };
        Integer[] animalID2 = {
                R.drawable.bear2, R.drawable.fox2, R.drawable.leopard2,
                R.drawable.lynx2, R.drawable.muskdeer2, R.drawable.otter2,
                R.drawable.sikadeer2, R.drawable.tiger2, R.drawable.wolf2
        };



        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final ImageView imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(150,120));
            imageView.setAdjustViewBounds(true);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(5,5,5,5);
            imageView.setImageResource(animalID[position]);

            final int pos = position;
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    View dialogView = (View) View.inflate(MainActivity.this,
                            R.layout.animal, null);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity.this);
                    final ImageView ivAnimal = (ImageView) dialogView.findViewById(R.id.ivAnimal);
                    final TextView species = (TextView) dialogView.findViewById(R.id.speices);
                    TextView habitat = (TextView) dialogView.findViewById(R.id.habitat);
                    TextView difference = (TextView) dialogView.findViewById(R.id.difference);

                    ivAnimal.setImageResource(animalID[pos]);
                    species.setText("종: "+animalSpecies[pos]);
                    habitat.setText("서식지: " + habitatPlace[pos]);
                    difference.setText("이명: " + differenceName[pos]);
                    dlg.setTitle(animalName[pos]);
                    dlg.setView(dialogView);
                    dlg.setNegativeButton("닫기", null);
                    dlg.show();
                    Toast.makeText(getApplicationContext(), "사진 터치(클릭 시) 상세정보 보기", Toast.LENGTH_SHORT).show();

                    ivAnimal.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
                            intent.putExtra("종", (CharSequence) animalSpecies[pos]);
                            intent.putExtra("서식지", (CharSequence) habitatPlace[pos]);
                            intent.putExtra("사진", animalID2[pos]);
                            startActivityForResult(intent, 0);
                        }
                    });
                }


            });
            return imageView;
        }
    }
}