package com.example.endageredanimal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import javax.xml.transform.Result;

public class SecondActivity extends AppCompatActivity {




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);

        Intent secintent = getIntent();
        String species = secintent.getStringExtra("종");
        setTitle(species + " 상세정보");

        int animalID2 = secintent.getIntExtra("사진", 0);
        ImageView secIV = (ImageView) findViewById(R.id.secIV);
        secIV.setImageResource(animalID2);

        String place = secintent.getStringExtra("서식지");
        TextView secTV = (TextView) findViewById(R.id.secTV);
        secTV.setText("서식지: "+ place);

        Button btnBack = (Button) findViewById(R.id.btnBack);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent outIntent = new Intent(getApplicationContext(),
                        MainActivity.class);
                setResult(RESULT_OK, outIntent);
                finish();
            }
        });

    }
}
